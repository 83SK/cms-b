import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hoddashboard',
  templateUrl: './hoddashboard.component.html',
  styleUrls: ['./hoddashboard.component.css']
})
export class HoddashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
