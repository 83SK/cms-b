import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import Swal from 'sweetalert2';

const endpoint = 'http://localhost:5050/api/departments';
let token = localStorage.getItem('token');

const httpOption = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    Authorization: `Bearer ${token}`,
  }),
};

@Component({
  selector: 'app-departments',
  templateUrl: './departments.component.html',
  styleUrls: ['./departments.component.css'],
})
export class DepartmentsComponent implements OnInit {
  constructor(private http: HttpClient) {this.getDepartments();}

  data: any = [];
  depName: any;
  updepName: any;
  ngOnInit(): void {
    this.getDepartments()
  }
  updatedId: string = '';

  getDepartments() {
    this.http.get(endpoint, httpOption).subscribe(
      (response: any) => {
        console.log(response);
        this.data = response.allDepartments;
      },
      (error) => {
        console.error('Error:', error);
        // Handle error here
      }
    );
  }
  createDepartment() {
    const endpoints = 'http://localhost:5050/api/departments/create';

    const formData = {
      name: this.depName.toUpperCase(),
    };

    this.http.post(endpoints, formData, httpOption).subscribe(
      (response: any) => {
        if (response.messageType === 'success') {
          this.getDepartments();
          this.depName = null;
          console.log(response);
        }
      },
      (error) => {
        console.error('Error:', error);
        // Handle error here
      }
    );
  }

  update(id: any) {
    console.log(id);
    this.updatedId = id;
    this.http.get(endpoint, httpOption).subscribe(
      (response: any) => {
        let upData;
        upData = response.allDepartments;

        upData.forEach((e: any) => {
          if (e._id === id) {
            console.log(e._id, id);
            this.updepName = e.name;
          }
        });
      },
      (error) => {
        console.error('Error:', error);
        // Handle error here
      }
    );
  }

  remove(id: any) {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You will not be able to recover this department!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'Cancel',
      confirmButtonColor: '#dc3545',
    }).then((result) => {
      if (result.isConfirmed) {
        const endpoints = `http://localhost:5050/api/departments/${id}`;
        this.http.patch(endpoints, null, httpOption).subscribe(
          (response: any) => {
            Swal.fire({
              title: 'Deleted!',
              text: 'Department has been deleted.',
              icon: 'success',
            });
            this.getDepartments();
          },
          (error) => {
            console.error('Error:', error);
          }
        );
      }
    });
  }

  updateDepartment() {
    const endpoints = `http://localhost:5050/api/departments/${this.updatedId}`;

    const dataUpdated = {
      name: this.updepName.toUpperCase(),
    };

    this.http.put(endpoints, dataUpdated, httpOption).subscribe(
      (response: any) => {
        // if (response.messageType === 'success') {
        // this.getDepartments();
        console.log(response);
        this.getDepartments();
        Swal.fire({
          title: 'Success!',
          text: 'Updates saved successfully.',
          icon: 'success',
        });
        // }
      },
      (error) => {
        console.error('Error:', error);
      }
    );
  }
}
