import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import Swal from 'sweetalert2';

const endpoint = 'http://localhost:5050/api/classes';
let token = localStorage.getItem('token');

const httpOption = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    Authorization: `Bearer ${token}`,
  }),
};

@Component({
  selector: 'app-classes',
  templateUrl: './classes.component.html',
  styleUrls: ['./classes.component.css'],
})
export class ClassesComponent implements OnInit {
  constructor(private http: HttpClient) {
    this.getStudents();
    this.getClassesByDepsAndYears();
  }

  detailedClassId:any;
  deletedStudentArray:any = []
  data: any = [];
  classes: any = [];
  teachers: any = [];
  subjects: any = [];
  createdClasses: any = [];
  selectedClassId: string = '';
  students: any = [];
  studentsId: any = [];
  addedStudentsId: any = '';
  filteredStudents: any = [];
  singleClassStudnets: any = [];
  singleClassTeacherAndSubject: any = [];
  singleClass: any;
  singleClassYear:any;
  singleClassInfo:any =[];
  singleClassTeacher:any;
  singleClassSubject:any;
  singleClassDepartment:any;
  selectedTeacherId: any;
  selectedSubjectId: any;
  selectedStudents: any = [];
  title: any;
  className: any;
  section: any;
  year: any;
  filterYear: any;
  email: any;
  pwd: any;
  upTitle: any;
  upYear: any;
  upEmail: any;
  depName: any;
  selectedOption: any;
  selectedClassOption: any;
  selectedStudentOption: any;
  isChecked: any;
  filteredDep: any;
  ngOnInit(): void {
    this.getDepartments();
    this.getClasses();
    // this.isChecked = new Array(this.students.length).fill(false);
    this.getClassesByDepsAndYears();
    this.getTeachers();
    this.getSubjects();
    this.classDetails(this.classId);
    this.addTeacherAndSubjectToClass();
  }
  updatedId: string = '';
  classId: string = '';

  getDepartments() {
    const endpoints = 'http://localhost:5050/api/departments';
    this.http.get(endpoints, httpOption).subscribe(
      (response: any) => {
        console.log(response);
        this.data = response.allDepartments;
        console.log(this.data);
      },
      (error) => {
        console.error('Error:', error);
        // Handle error here
      }
    );
  }

  getStudents() {
    const url = 'http://localhost:5050/api/students';
    this.http.get(url, httpOption).subscribe(
      (response: any) => {
        console.log(response);
        this.students = response.allStudents;
        console.log(this.students);
      },
      (error) => {
        console.error('Error:', error);
        // Handle error here
      }
    );
  }

  createClass() {
    const addStudents = {
      student: this.selectedStudentOption,
    };

    console.log(addStudents);
    const endpoints = 'http://localhost:5050/api/classes/create';
    this.title = this.className + this.section;
    console.log(this.title);
    const formData = {
      title: this.title.toUpperCase(),
      year: this.year,
      department: this.selectedOption,
    };

    console.log(formData);

    this.http.post(endpoints, formData, httpOption).subscribe(
      (response: any) => {
        console.log(response);
        if (response.messageType === 'success') {
          this.getClasses();
          console.log(response);
        }
      },
      (error) => {
        console.error('Error:', error);
      }
    );
  }

  getClasses() {
    const url = 'http://localhost:5050/api/classes';
    this.http.get(url, httpOption).subscribe(
      (response: any) => {
        console.log(response);
        this.classes = response.classes;
        // console.log(this.classes);
      },
      (error) => {
        console.error('Error:', error);
        // Handle error here
      }
    );
  }

  update(id: any) {
    console.log(id);
    this.updatedId = id;
    this.http.get(endpoint, httpOption).subscribe(
      (response: any) => {
        let upClasses;
        upClasses = response.classes;

        upClasses.forEach((e: any) => {
          if (e._id === id) {
            console.log(e._id, id);
            this.upTitle = e.title;
            this.upYear = e.year;
          }
        });
      },
      (error) => {
        console.error('Error:', error);
        // Handle error here
      }
    );
  }

  updateClasses() {
    const endpoints = `http://localhost:5050/api/classes/${this.updatedId}`;

    const hodUpdated = {
      title: this.upTitle,
      year: this.upYear,
    };

    this.http.put(endpoints, hodUpdated, httpOption).subscribe(
      (response: any) => {
        // if (response.messageType === 'success') {
        // this.getDepartments();
        console.log(response);
        this.getClasses();
        Swal.fire({
          title: 'Success!',
          text: 'Updates saved successfully.',
          icon: 'success',
        });
        // }
      },
      (error) => {
        console.error('Error:', error);
      }
    );
  }

  remove(id: any) {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You will not be able to recover this class!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'Cancel',
      confirmButtonColor: '#dc3545',
    }).then((result) => {
      if (result.isConfirmed) {
        const endpoints = `http://localhost:5050/api/classes/${id}`;
        this.http.patch(endpoints, null, httpOption).subscribe(
          (response: any) => {
            Swal.fire({
              title: 'Deleted!',
              text: 'Class has been deleted.',
              icon: 'success',
            });
            this.getClasses();
          },
          (error) => {
            console.error('Error:', error);
          }
        );
      }
    });
  }
  getClassesByDepsAndYears() {
    const url = 'http://localhost:5050/api/classes/filtered';
    const deps = {
      department: this.filteredDep,
      year: this.filterYear,
    };
    const depps = deps.department == '' ? null : deps;
    console.log(depps);
    this.http.post(url, depps, httpOption).subscribe(
      (response: any) => {
        console.log('filter', response);
        this.createdClasses = response.classes;
        this.filteredStudents = response.students;
        this.studentsId = response.students._id;
        console.log(this.studentsId);
        console.log(this.createdClasses);
        console.log(this.filteredStudents);
      },
      (error) => {
        console.error('Error:', error);
        // Handle error here
      }
    );
  }

  addStudentToClass() {
    console.log('first', 'student to class');
    console.log('class-id', this.selectedClassId);
    console.log('class-id', this.studentsId);
    const endpoints = `http://localhost:5050/api/classes/${this.selectedClassId}/add-students`;
    const addStudents = {
      students: this.selectedStudents,
    };
    console.log('added student', addStudents);
    this.http.post(endpoints, addStudents, httpOption).subscribe(
      (response: any) => {
        console.log(response);
        if (response.messageType === 'success') {
          this.getClasses();
          console.log(response);
        }
      },
      (error) => {
        console.error('Error:', error);
      }
    );
  }

  getTeachers() {
    const url = 'http://localhost:5050/api/teachers';
    this.http.get(url, httpOption).subscribe(
      (response: any) => {
        console.log(response);
        this.teachers = response.teachers;
        // console.log(this.teachers);
      },
      (error) => {
        console.error('Error:', error);
        // Handle error here
      }
    );
  }

  getSubjects() {
    const url = 'http://localhost:5050/api/subjects';
    this.http.get(url, httpOption).subscribe(
      (response: any) => {
        console.log(response);
        this.subjects = response.allSubjects;
        console.log(this.subjects);
      },
      (error) => {
        console.error('Error:', error);
        // Handle error here
      }
    );
  }
  addTeacherAndSubjectToClass() {
    console.log('first', 'student to class');
    console.log('class-id', this.selectedClassId);
    const endpoints = `http://localhost:5050/api/classes/${this.selectedClassId}/add-info`;
    const addTeacherAndSubjets = {
      teacher: this.selectedTeacherId,
      subject: this.selectedSubjectId,
    };
    console.log(addTeacherAndSubjets);
    this.http.post(endpoints, addTeacherAndSubjets, httpOption).subscribe(
      (response: any) => {
        console.log(response);
        if (response.messageType === 'success') {
          // this.getClasses();
          console.log(response);
        }
      },
      (error) => {
        console.error('Error:', error);
      }
    );
  }
  filter(e: any) {
    this.filteredDep = e.target.value;
    this.getClassesByDepsAndYears();
    console.log(e.target.value);
  }
  filterYearr(e: any) {
    this.filterYear = e.target.value;
    this.getClassesByDepsAndYears();
    console.log(e.target.value);
  }

  updateSelectedStudents(checked: any, student: any) {
    console.log(student);
    if (checked.target.checked) {
      console.log('checked', checked.target.checked);
      this.selectedStudents.push(student._id);
      console.log(this.selectedStudents);
    } else {
      console.log('unchecked', checked.target.checked);
      const index = this.selectedStudents.indexOf(student.firstName);
      if (index !== -1) {
        this.selectedStudents.splice(index, 1);
        console.log(this.selectedStudents);
      }
    }
  }

  classDetails(classId: any) {
    this.detailedClassId = classId
    console.log(classId);
    const url = `http://localhost:5050/api/classes/${classId}/details`;
    this.http.get(url, httpOption).subscribe(
      (response: any) => {
        console.log(response);
        this.singleClassStudnets = response.class.students;
        this.singleClassTeacherAndSubject = response.class.info;
        this.singleClass = response.class.title;
        this.singleClassYear = response.class.year;
        this.singleClassInfo = response.class.info;
        this.singleClassTeacher = this.singleClassInfo.teacher.firstName;
        this.singleClassSubject = this.singleClassInfo.subject.title + response.class.info.subject.code;
        this.singleClassDepartment = response.class.department.name;
        console.log(this.singleClassStudnets);
        console.log(this.singleClassTeacherAndSubject);
        console.log(this.singleClass);
        console.log(this.singleClassYear);
        console.log(this.singleClassTeacher);
        console.log(this.singleClassSubject);
        console.log(this.singleClassDepartment);
      },
      (error) => {
        console.error('Error:', error);
        // Handle error here
      }
    );
  }

  removeStudentfromClass(id:any) {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You will not be able to recover this class!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'Cancel',
      confirmButtonColor: '#dc3545',
    }).then((result) => {
      if (result.isConfirmed) {
        const endpoints = `http://localhost:5050/api/classes/${this.detailedClassId}/remove-students`;
        // this.deletedStudentArray.push(id);
        // console.log(this.deletedStudentArray);
        const formData = {
            students: [id]
        }
        this.http.post(endpoints, formData, httpOption).subscribe(
          (response: any) => {
            console.log(response)
            if(response.messageType === "success"){
              this.classDetails(this.classId)
              Swal.fire({
                title: 'Deleted!',
                text: 'Class has been deleted.',
                icon: 'success',
              });
            }

          },
          (error) => {
            console.error('Error:', error);
          }
        );
      }
    });
  }

  removeInfofromClass(id:any) {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You will not be able to recover this class!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'Cancel',
      confirmButtonColor: '#dc3545',
    }).then((result) => {
      if (result.isConfirmed) {
        const endpoints = `http://localhost:5050/api/classes/${this.detailedClassId}/remove-info`;
        // this.deletedStudentArray.push(id);
        // console.log(this.deletedStudentArray);
        const formData = {
            infoId: id
        }
        this.http.post(endpoints, formData, httpOption).subscribe(
          (response: any) => {
            console.log(response)
            if(response.messageType === "success"){
              this.classDetails(this.classId)
              Swal.fire({
                title: 'Deleted!',
                text: 'Class has been deleted.',
                icon: 'success',
              });
            }

          },
          (error) => {
            console.error('Error:', error);
          }
        );
      }
    });
  }

  // onCheckboxChange(event: any) {
  //   if (event.target.checked) {
  //     console.log('Checkbox is checked');
  //   } else {
  //     console.log('Checkbox is not checked');
  //   }
  // }
}
