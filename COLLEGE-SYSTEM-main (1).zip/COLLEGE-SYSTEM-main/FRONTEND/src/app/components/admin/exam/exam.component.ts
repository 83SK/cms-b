import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import Swal from 'sweetalert2';

let token = localStorage.getItem('token');

const httpOption = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    Authorization: `Bearer ${token}`,
  }),
};
@Component({
  selector: 'app-exam',
  templateUrl: './exam.component.html',
  styleUrls: ['./exam.component.css'],
})
export class ExamComponent implements OnInit {
  teacherExams: any;
  loginIUserId: any;
  examsDetailss: any = [];
  examsClassDetails: any;
  examsLessonDetails: any;
  examsSubjectDetails: any;
  examsTeacherDetails: any;
  examsDepartmentDetails: any;
  examsStudentsDetails: any = [];
  examGlobalId: any;
  selectedObtainMarks: any = []
  studentRole: any;
  selectedClassOption: any;
  departmentName: any;
  classYear: any;
  className: any;
  name: any;
  hodRole: any;
  teacherRole: any;
  classId: any;
  studentAttendances: any = [];
  classes: any = [];
  myStudents: any = [];
  parentRole: any;

  constructor(private http: HttpClient) {
    this.loginIUserId = JSON.parse(localStorage.getItem('userId') as any);
    console.log('userId', this.loginIUserId._id);
    this.studentRole =
    this.loginIUserId.role === 'STUDENT' || this.loginIUserId.role === 'PARENT'
      ? true
      : false;
    this.hodRole =
    this.loginIUserId.role === 'HOD' || this.loginIUserId.role === 'ADMIN'
      ? true
      : false;
    this.parentRole =
    this.loginIUserId.role === 'PARENT'
      ? true
      : false;
    this.teacherRole =
    this.loginIUserId.role === 'TEACHER'
      ? true
      : false;
  }

  ngOnInit(): void {
    this.getExams(this.classId);
    this.getStudentsDetails();
    this.getClasses();
    this.getSingleParent();
    // this.examDetails(this.examId);
  }
  getClassID(){
    console.log(this.selectedClassOption)
    this.classId = this.selectedClassOption
    this.getExams(this.classId)
  }

  getExams(cId:any) {
    if(this.loginIUserId.role === "TEACHER"){
      const formData = {
        teacher: this.loginIUserId._id,
      };
      const url = `http://localhost:5050/api/exams/filtered`;
      this.http.post(url, formData, httpOption).subscribe(
        (response: any) => {
          console.log(response);
          this.teacherExams = response.exams;
          // console.log(this.teacherExams);
        },
        (error) => {
          console.error('Error:', error);
          // Handle error here
        }
      );
    }else if(this.loginIUserId.role === "ADMIN" || this.loginIUserId.role === "HOD"){
      if(
        cId != null || undefined
      ){
      const formData = {
        class: this.selectedClassOption,
      };
      console.log(formData)
      const url = `http://localhost:5050/api/exams/filtered`;
      this.http.post(url, formData, httpOption).subscribe(
        (response: any) => {
          console.log(response);
          this.teacherExams = response.exams;
          // console.log(this.teacherExams);
        },
        (error) => {
          console.error('Error:', error);
          // Handle error here
        }
      );
    }
    }


  }

  examDetails(examId: any) {
    this.examGlobalId = examId;
    console.log(examId);
    const url = `http://localhost:5050/api/exams/${examId}/details`;
    this.http.get(url, httpOption).subscribe(
      (response: any) => {
        console.log(response.exam.students);
        this.examsClassDetails = response.exam.class.title;
        this.examsSubjectDetails = response.exam.subject.title;
        this.examsTeacherDetails =
          response.exam.teacher.firstName +
          ' ' +
          response.exam.teacher.lastName;
        this.examsDepartmentDetails = response.exam.department.name;
        this.examsStudentsDetails = response.exam.students;
        //  this.examsDetailss.push(response.exam);
        //  this.examDetailss.forEach((value:any) => {
        //   console.log(value)
        //  })
        //  this.examsClassDetails = response.exam.class;
        //  console.log(this.examsDetailss.class);
      },
      (error) => {
        console.error('Error:', error);
        // Handle error here
      }
    );
  }

  upDateExamsMarks() {
    const endpoints = `http://localhost:5050/api/exams/${this.examGlobalId}`;
    // console.log(this.examGlobalId);
    const students = [];

    for (let i = 0; i < this.examsStudentsDetails.length; i++) {
      const examStudent = this.examsStudentsDetails[i];
      const obtainedMarks = this.selectedObtainMarks[i]; // get obtainedMarks value from selectedObtainMarks array at index i if it exists
      const student = {
        student: examStudent.student._id,
        obtainedPercentage: obtainedMarks
      };
      students.push(student);
    }
    console.log(students)
    this.http.put(endpoints, {students}, httpOption).subscribe(
      (response: any) => {
        console.log(response);
        if (response.messageType === 'success') {
          // this.getDepartments();
          console.log(response);
        Swal.fire({
          title: 'Success!',
          text: 'Marks saved successfully.',
          icon: 'success',
        });
        }
      },
      (error) => {
        console.error('Error:', error);
      }
    );
  }

  getStudentsDetails() {
    const url = `http://localhost:5050/api/students/${this.loginIUserId._id}/details`;
    this.http.get(url, httpOption).subscribe(
      (response: any) => {
        this.name = response.student.firstName + ' ' + response.student.lastName
        this.className = response.student.class.title;
        this.classYear = response.student.class.year;
        this.departmentName = response.student.department.name;
        this.studentAttendances = response.student.exams;
        console.log(response);
        console.log(this.studentAttendances);
        // this.students = response.allStudents;
        // console.log(this.students);
      },
      (error) => {
        console.error('Error:', error);
        // Handle error here
      }
    );
  }




  getClasses() {

    const url = 'http://localhost:5050/api/classes';
    this.http.get(url, httpOption).subscribe(
      (response: any) => {
        console.log(response);
        this.classes = response.classes;
        // console.log(this.classes);
      },
      (error) => {
        console.error('Error:', error);
        // Handle error here
      }
    );
  }

  getFilteredExams(){

  }

  getSingleParent(){
    console.log(this.loginIUserId._id)
    const url = `http://localhost:5050/api/parents/${this.loginIUserId._id}/details`;
    this.http.get(url, httpOption).subscribe(
      (response: any) => {
        // this.name = response.student.firstName + ' ' + response.student.lastName
        // this.className = response.student.class.title;
        // this.classYear = response.student.class.year;
        // this.departmentName = response.student.department.name;
        // this.studentAttendances = response.student.attendances;
        console.log(response);
        this.myStudents = response.parent.students
        // this.parent = response.parent.students
        // this.students = response.allStudents;
        // console.log(this.students);
      },
      (error) => {
        console.error('Error:', error);
        // Handle error here
      }
    );
  }



}
