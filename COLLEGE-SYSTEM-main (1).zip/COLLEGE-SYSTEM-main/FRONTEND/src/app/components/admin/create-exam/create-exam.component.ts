import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

const endpoint = 'http://localhost:5050/api/students';
let token = localStorage.getItem('token');

const httpOption = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    Authorization: `Bearer ${token}`,
  }),
};

@Component({
  selector: 'app-create-exam',
  templateUrl: './create-exam.component.html',
  styleUrls: ['./create-exam.component.css']
})
export class CreateExamComponent implements OnInit {
  loginIUserId: any;
  selectedTermOption: any='';
  selectedTotalMarksOption: any='';
  selectedPassingMarksOption: any='';
  selectedDepOption: any='';
  selectedTeacherOption: any='';
  selectedClassOption: any='';
  selectedSubjectOption: any='';
  selectedDateOption: any='';
  selectedMonthOption: any='';
  selectedYearOption: any = '';
  AllClasses: any = [];
  AllSubjects: any = [];
  allStudents: any = [];
  presentStudents: any[] = [];
  presentData: any;
  teacherinfo: any = [];
  subjects: any = [];
  classes: any = [];
  teachers: any = [];
  data: any = [];

  date: any = [
    '1',
    '2',
    '3',
    '4',
    '5',
    '6',
    '7',
    '8',
    '9',
    '10',
    '11',
    '12',
    '13',
    '14',
    '15',
    '16',
    '17',
    '18',
    '19',
    '20',
    '21',
    '22',
    '23',
    '24',
    '25',
    '26',
    '27',
    '28',
    '29',
    '30',
    '31',
  ];
  month: any = [
    'JANUARY',
    'FEBRUARY',
    'MARCH',
    'APRIL',
    'MAY',
    'JUNE',
    'JULY',
    'AUGUST',
    'SEPTEMBER',
    'OCTUBER',
    'NOVEMBER',
    'DECEMBER',
  ];

  term:any=['First Term', 'Mid Term', 'Final']
  singleClassStudnets: any=[];
  allSingleStudnetId: any=[];
  constructor(private http: HttpClient) {  }

  ngOnInit(): void {
    this.getSubjects();
    this.getClasses();
    this.getTeachers();
    this.getDepartments();
  }

  getDepartments() {
    const endpoints = 'http://localhost:5050/api/departments';
    this.http.get(endpoints, httpOption).subscribe(
      (response: any) => {
        console.log(response);
        this.data = response.allDepartments;
        console.log(this.data);
      },
      (error) => {
        console.error('Error:', error);
        // Handle error here
      }
    );
  }

  getSubjects() {
    const url = 'http://localhost:5050/api/subjects';
    this.http.get(url, httpOption).subscribe(
      (response: any) => {
        console.log(response);
        this.subjects = response.allSubjects;
        console.log(this.subjects);
      },
      (error) => {
        console.error('Error:', error);
        // Handle error here
      }
    );
  }


  getClasses() {
    const url = 'http://localhost:5050/api/classes';
    this.http.get(url, httpOption).subscribe(
      (response: any) => {
        console.log(response);
        this.classes = response.classes;
        // console.log(this.classes);
      },
      (error) => {
        console.error('Error:', error);
        // Handle error here
      }
    );
  }

  getTeachers() {
    const url = 'http://localhost:5050/api/teachers';
    this.http.get(url, httpOption).subscribe(
      (response: any) => {
        console.log(response);
        this.teachers = response.teachers;
        // console.log(this.teachers);
      },
      (error) => {
        console.error('Error:', error);
        // Handle error here
      }
    );
  }
  getVal(){
    console.log({title: this.selectedTermOption});
    console.log({title: this.selectedClassOption});
    this.classDetails()
  }



   classDetails() {
    const url = `http://localhost:5050/api/classes/${this.selectedClassOption}/details`;
    this.http.get(url, httpOption).subscribe(
      (response: any) => {
        console.log(response);
        this.singleClassStudnets = response.class.students;
        this.singleClassStudnets.forEach((student:any) => {
          this.allSingleStudnetId.push({student: student._id})
        })
        console.log(this.singleClassStudnets)
        console.log(this.allSingleStudnetId)
      },
      (error) => {
        console.error('Error:', error);
        // Handle error here
      }
    );
  }

getFormData() {
  const endpoints = `http://localhost:5050/api/exams/create`;
  const formData ={
    title: this.selectedTermOption,
    totalPercentage: this.selectedTotalMarksOption,
    passingPercentage: this.selectedPassingMarksOption,
    teacher: this.selectedTeacherOption,
    class: this.selectedClassOption,
    department: this.selectedDepOption,
    subject: this.selectedSubjectOption,
    students: this.allSingleStudnetId,
    day: this.selectedDateOption,
    month: this.selectedMonthOption,
    year: this.selectedYearOption,
  }
  console.log(formData);
  this.http.post(endpoints, formData, httpOption).subscribe(
    (response: any) => {
      console.log(response);
      if (response.messageType === 'success') {
        // this.getClasses();
        console.log(response);
      }
    },
    (error) => {
      console.error('Error:', error);
    }
  );
}

getStudentId(){
  const classId = {
    class: this.selectedClassOption
  }
}

}
