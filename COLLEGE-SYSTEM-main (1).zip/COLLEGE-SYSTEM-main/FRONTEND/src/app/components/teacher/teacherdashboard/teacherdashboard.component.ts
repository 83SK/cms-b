import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teacherdashboard',
  templateUrl: './teacherdashboard.component.html',
  styleUrls: ['./teacherdashboard.component.css']
})
export class TeacherdashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
