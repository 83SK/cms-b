// REQUIRED STUFF
import UsersModel from "../../../Models/UsersModel/UsersModel.mjs";

const Users = UsersModel;

const Controllers = {
  // CREATE NEW USER
  createNewUser: async (x) => {
    
  }
}

export default Controllers;