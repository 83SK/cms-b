// REQUIRED STUFF
import UsersModel from "../../Models/UsersModel/UsersModel.mjs";
import HODsModel from "../../Models/HODsModel/HODsModel.mjs";
import TeachersModel from "../../Models/TeachersModel/TeachersModel.mjs";
import StudentsModel from "../../Models/StudentsModel/StudentsModel.mjs";
import ParentsModel from "../../Models/ParentsModel/ParentsModel.mjs";
import jsonwebtoken from "jsonwebtoken";
import speakeasy from "speakeasy";
import qrcode from "qrcode";
import * as dotenv from "dotenv";

// .ENV CONFIGURATION
dotenv.config();

// MODELS
const Users = UsersModel;
const HODs = HODsModel;
const Teachers = TeachersModel;
const Students = StudentsModel;
const Parents = ParentsModel;

// SETUP FOR OTP
// const secret = speakeasy.generateSecret({ length: 20 });
// const otpauth = speakeasy.otpauthURL({ secret: secret.base32, label: 'CMS' });
// qrcode.toDataURL(otpauth, function (err, dataURL) {
//   console.log(dataURL);
//   console.log(secret, "Secret");
// });

const Controllers = {

  // REGISTER USER
  register: async (x) => {
    // GENERATE OTP STRING
    const otpString = speakeasy.generateSecret({ length: 20 });

    // CHECK IF EMAIL ALREADY EXISTS
    let alreadyExist = await Users.findOne({ email: x.email.toLowerCase() });
    if (alreadyExist) {
      return { message: "This email is already registered", messageType: "warning" };
    }

    // CREATING NEW USER
    let user = new Users({
      firstName: x.firstName,
      lastName: x.lastName,
      email: x.email.toLowerCase(),
      password: x.password,
      role: x.role.toUpperCase(),
      otpString: otpString.base32
    });

    // SAVE USER IN DATABASE & SEND RESPONSE
    user = await user.save();
    return user ? { message: "User registered successfully.", messageType: "success" } : { message: "User couldn't registered", messageType: "error" };
  },

  // SIGN IN USER
  signIn: async (x) => {
    // CHECKING CREDENTIALS
    let userLoggedIn = null;

    switch (x.role) {
      case "ADMIN":
        await Users.findOne({ email: x.email, password: x.password })
          .then((result) => {
            userLoggedIn = result;
          })
          .catch((error) => {
            console.log(error);
          });
        break;

      case "HOD":
        await HODs.findOne({ email: x.email, password: x.password })
          .then((result) => {
            userLoggedIn = result;
          })
          .catch((error) => {
            console.log(error);
          });
        break;

      case "TEACHER":
        await Teachers.findOne({ email: x.email, password: x.password })
          .then((result) => {
            userLoggedIn = result;
          })
          .catch((error) => {
            console.log(error);
          });
        break;

      case "STUDENT":
        await Students.findOne({ email: x.email, password: x.password })
          .then((result) => {
            userLoggedIn = result;
          })
          .catch((error) => {
            console.log(error);
          });
        break;

      case "PARENT":
        await Parents.findOne({ email: x.email, password: x.password })
          .then((result) => {
            userLoggedIn = result;
          })
          .catch((error) => {
            console.log(error);
          });
        break;

      default:
        return { message: "Invalid role selected.", messageType: "error" };
    }



    // FOUND SEND RESPONSE WITH TOKEN
    if (userLoggedIn) {
      console.log(userLoggedIn.otpString, "SIGN IN");
      // SETUP FOR OTP & QRCODE
      const otpauth = speakeasy.otpauthURL({ secret: userLoggedIn.otpString, label: 'CMS', period: 180, encoding: "base32" });
      let QRCode = await qrcode.toDataURL(otpauth);

      const { _id, firstName, lastName, email, role } = userLoggedIn;
      const token = jsonwebtoken.sign({ user: { _id, firstName, lastName, email, role } }, process.env.JWT_SECRET, { expiresIn: "1h" });

      return { message: "You've signed in successfully.", messageType: "success", token, isAuthenticated: false, QRCode };
    }

    // USER NOT FOUND
    if (!userLoggedIn) {
      return { message: "Invalid email or password.", messageType: "warning" };
    }

    // NOTHING HAPPENS
    return { message: "Something went wrong, please try again later.", messageType: "error" };
  }
}

export default Controllers;